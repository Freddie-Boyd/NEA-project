import pygame
import math
import random

import os
import sys

os.environ['SDL_VIDEO_CENTERED'] = "1"

pygame.init()

info = pygame.display.Info()
SCREEN_WIDTH, SCREEN_HEIGHT = info.current_w, info.current_h
#SCREEN_WIDTH, SCREEN_HEIGHT = 1080, 700

from Spritesheet import Spritesheet
from Character import Player, Enemy
from Floor import Floor_generator
from Combat import Combat
from Weapon_gen import Weapon_generator

clock = pygame.time.Clock()

SPRITE_SHEET_IMAGE = "Sprites/Sprite_sheets/Sprite_sheet.png"
SPRITESHEET_TEXT_FILENAME = "character_sprites"

BACKGROUND_IMAGE = "Backgrounds/Game_background.jpg"

FPS = 30

pygame.mouse.set_cursor(pygame.cursors.Cursor(*pygame.cursors.tri_left)) #remove when moved into Main

class Dungeon:
    def __init__(self):
        self.screen = pygame.display
        self.screen_rect = self.screen.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))   
        
        self.tile_size = 64
        
        self.sprite_sheet = Spritesheet(SPRITE_SHEET_IMAGE, self.tile_size, SPRITESHEET_TEXT_FILENAME)
        
        self.floor_obj = Floor_generator(self.screen_rect.get_rect().width, self.screen_rect.get_rect().height, self.tile_size, self.sprite_sheet.floor, self.sprite_sheet.wall2)
        
        self.define_vars()
        
        self.make_dungeon()
        
        self.weapon_generator = Weapon_generator()
        
        self.character.pick_up_item(self.weapon_generator.generate_random_weapons(1, 1))
        
        temp1 = {
            "weapon_type": "Sword",
            "element": "Fire",
            "tier": "A"
                }
        temp2 = {
            "weapon_type": "Hammer",
            "element": None,
            "tier": "C"
                }
        temp3 = {
            "weapon_type": "Dagger",
            "element": None,
            "tier": "S"            
        }
        temp4 = {
            "weapon_type": "Shortsword",
            "element": "Fire",
            "tier": "S"  
        }
        self.temp5 = {
            "weapon_type": "Axe",
            "element": "Lightning",
            "tier": "S"
        }
        
        a = [temp1, temp2, temp3, temp4]
        for i in a:
            self.character.pick_up_item(self.weapon_generator.generate_specific_weapon(i))
        self.character.set_equipped_index(0)
    
    def define_vars(self):
        start_location = self.floor_obj.get_start_location()
        self.bl_player_x = start_location[0] * self.tile_size
        self.bl_player_y = (start_location[1] + 1) * self.tile_size
        
        self.tile_images = {"floor_1": pygame.transform.scale(self.sprite_sheet.floor, (self.tile_size, self.tile_size)), "wall_2": pygame.transform.scale(self.sprite_sheet.wall2, (self.tile_size, self.tile_size))}
        
        self.characters = {"elf_f":{"STR": 8, "CON": 9, "DEX": 11}, "elf_m":{"STR": 8, "CON": 9, "DEX": 11}, "knight_f":{"STR": 12, "CON": 12, "DEX": 8}, "knight_m":{"STR": 12, "CON": 12, "DEX": 8}, "wizzard_f":{"STR": 8, "CON": 9, "DEX": 11}, "wizzard_m":{"STR": 8, "CON": 9, "DEX": 11}, "lizard_f":{"STR": 12, "CON": 10, "DEX": 10}, "lizard_m":{"STR": 12, "CON": 10, "DEX": 10}, "big_zombie":{"STR": 16, "CON": 16, "DEX": 10}}#, "ogre", "big_demon", "tiny_zombie", "goblin", "imp", "skelet", "muddy", "swampy", "zombie", "ice_zombie", "masked_orc", "orc_warrior", "orc_shaman", "necromancer", "wogol", "chort"}
        count = 0
        for i in self.characters.keys():
            if count == 0:
                self.character_name = i
            count += 1
        self.character = Player(self.sprite_sheet.get_sprite("character_sprites", self.character_name), (self.bl_player_x, self.bl_player_y), self.characters[self.character_name], self.tile_size)        
        
        self.grid = []    

        directory = BACKGROUND_IMAGE
        self.background_image = pygame.image.load(directory).convert_alpha()
        self.background_image = pygame.transform.scale(self.background_image, (self.screen_rect.get_rect().width, self.screen_rect.get_rect().height))
    
    def handle_player_death(self):
        pass
    
    def start_loop(self):
        
        self.to_print = [self.character]

        self.x_offset = -self.screen_rect.get_rect().width//2 + self.bl_player_x
        self.y_offset = -self.screen_rect.get_rect().height//2 + self.bl_player_y

        run = True
        self.monsters = []
        self.monsters_to_activate = []
        i = 0
        self.frame = 0
        self.new_frame = pygame.USEREVENT + 0
        self.ready_to_fight = pygame.USEREVENT + 1
        pygame.time.set_timer(self.new_frame, 125)
        while run:
            if not self.character.get_alive():
                self.handle_player_death()
                return
            
            self.screen_rect.blit(self.background_image, (0, 0))   
    
            self.draw_dungeon()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                    run = False
                if event.type == self.new_frame:
                    self.frame += 1
                    if self.frame == 4:
                        self.frame = 0
                if event.type == self.ready_to_fight:
                    for monster in self.monsters_to_activate[0]:
                        monster.set_ready_to_fight(True)
                    self.monsters_to_activate = self.monsters_to_activate[1:]
                    if self.monsters_to_activate == []:
                        pygame.time.set_timer(self.ready_to_fight, 0)
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE:
                        i += 1
                        if i == len(self.characters):
                            i = 0
                        self.to_print.remove(self.character)
                        count = 0
                        for j in self.characters.keys():
                            if count == i:
                                self.character_name = j
                            count += 1
                        self.character = Player(self.sprite_sheet.get_sprite("character_sprites", self.character_name), (self.bl_player_x, self.bl_player_y), self.characters[self.character_name], self.tile_size)
                        self.to_print.append(self.character)
                    if event.key == pygame.K_m:
                        self.spawn_monster()
                    if event.key == pygame.K_t:
                        self.character.pick_up_item(self.weapon_generator.generate_random_weapons(1, 1))
                            
            keys = pygame.key.get_pressed()
            
            self.make_char_movements(keys)

            self.update_monster()

            self.draw_characters()
            
            self.screen_rect.blit(self.update_fps(), (10,0))
            
            clock.tick(FPS)
            
            self.screen.update()
    
    def update_fps(self):
        font = pygame.font.SysFont("Arial", 18)
        fps = str(int(clock.get_fps()))
        fps_text = font.render(fps, 1, pygame.Color("coral"))
        return fps_text        
    
    def move_monster(self, monster):
        self.character.get_rect().clipline((monster.get_bottom_left()), (self.character.get_bottom_left()))
        new_pos_rect_x, new_pos_rect_y = monster.move_to_pos(self.character.hit_box_rect.bottomleft)
        if self.is_valid_pos(new_pos_rect_x):
            x_pos = new_pos_rect_x.bottomleft[0]
            monster.move_character_x(x_pos)
            monster.update_moving(True)
        if self.is_valid_pos(new_pos_rect_y):
            y_pos = new_pos_rect_y.bottomleft[1]
            monster.move_character_y(y_pos)
            monster.update_moving(True)
    
    def spawn_monster(self):
        temp = ["ogre", "big_demon", "tiny_zombie", "goblin", "imp", "skelet", "muddy", "swampy", "zombie", "ice_zombie", "masked_orc", "orc_warrior", "orc_shaman"]
        #temp = ["swampy"]
        char = temp[random.randint(0, len(temp) - 1)]
        monster = Enemy(self.sprite_sheet.get_sprite("character_sprites", char), self.character.get_top_left(), char, self.tile_size)
        self.monsters.append(monster)
        self.to_print.append(monster)
        
    def start_combat(self, player, enemies):
        c = Combat(player, enemies, self.screen_rect, self.tile_size)
        did_player_win = c.start_combat() #set lost object to have alive status to False
        if did_player_win:
            self.handle_player_win(enemies)
        
    def handle_player_win(self, enemies):
        pass
            
    def update_monster(self):
        for monster in self.monsters:
            if monster.get_alive() and monster.get_ready_to_fight():
                self.move_monster(monster)
                if self.check_for_collide(self.character, monster):
                    monsters = self.find_close_enemies(monster, 3, 300)
                    self.start_combat(self.character, monsters)
                    self.monsters_to_activate.append(monsters)
                    pygame.time.set_timer(self.ready_to_fight, 600)
                    
                
    def find_close_enemies(self, entity, maximum_enemies, max_dis):
        close_entities = {}
        bottom_left = entity.get_bottom_left()
        for monster in self.monsters:
            if monster.get_ready_to_fight() and monster.get_alive():
                entity_bottom_left = monster.get_bottom_left()
                dis = math.sqrt((entity_bottom_left[0] - bottom_left[0])**2 + (entity_bottom_left[1] - bottom_left[1])**2)
                if dis < max_dis:
                    close_entities[monster] = dis
        close_entities = self.order_dict_small_to_large(close_entities)
        return close_entities[:maximum_enemies]
        
    def check_for_collide(self, character, entity):
        return character.check_collide(entity.get_hit_box_rect())
        
    def make_char_movements(self, keys):
        if keys[pygame.K_a] > keys[pygame.K_d]:
            self.character.update_facing_east(False)
            self.character.update_moving(True)
        elif keys[pygame.K_a] < keys[pygame.K_d]:
            self.character.update_facing_east(True)
            self.character.update_moving(True)
        elif keys[pygame.K_w] != keys[pygame.K_s]:
            self.character.update_moving(True)
        else:
            self.character.update_moving(False)
    
        temp_x1 = (keys[pygame.K_d] - keys[pygame.K_a]) * self.character.speed * (self.tile_size/32)
        temp_y1 = (keys[pygame.K_s] - keys[pygame.K_w]) * self.character.speed * (self.tile_size/32)
    
        new_x_hit_box_rect = self.character.get_hit_box_rect().copy()
        new_x_hit_box_rect.bottomleft = (self.bl_player_x + temp_x1, self.bl_player_y)
    
        new_y_hit_box_rect = self.character.get_hit_box_rect().copy()
        new_y_hit_box_rect.bottomleft = (self.bl_player_x, self.bl_player_y + temp_y1)
        
        new_x_y_hit_box_rect = self.character.get_hit_box_rect().copy()
        new_x_y_hit_box_rect.bottomleft = (self.bl_player_x + temp_x1, self.bl_player_y + temp_y1)
    
        valid_x_move = self.is_valid_pos(new_x_hit_box_rect)
        valid_y_move = self.is_valid_pos(new_y_hit_box_rect)
        valid_x_and_y = self.is_valid_pos(new_x_y_hit_box_rect)

        if valid_x_and_y:
            self.x_offset += temp_x1
            self.y_offset += temp_y1
            self.bl_player_x = self.bl_player_x + temp_x1
            self.bl_player_y = self.bl_player_y + temp_y1
        else:
            if valid_x_move:
                self.x_offset += temp_x1
                self.bl_player_x = self.bl_player_x + temp_x1
            elif valid_y_move:
                self.y_offset += temp_y1
                self.bl_player_y = self.bl_player_y + temp_y1

        self.character.move_character((self.bl_player_x, self.bl_player_y))    
    
    def get_close_not_walkable(self, grid_pos):
        to_check = []
        for row in range(-1, 2):
            for column in range(-1, 2):
                try:
                    tile = self.grid[grid_pos[0] + row][grid_pos[1] + column]
                except:
                    tile = None
                if tile is not None and not tile.is_walkable:
                    to_check.append(tile)
        return to_check
    
    def is_valid_pos(self, rect):
        grid_pos = self.get_grid_cord(rect)
        to_check = self.get_close_not_walkable(grid_pos)
        for tile in to_check:
            if tile.is_colliding(rect):
                return False
        return True
    
    def get_grid_cord(self, rect):
        column = round(rect.center[0]//self.tile_size)
        row = round(rect.center[1]//self.tile_size)
        return [column, row]

    def make_dungeon(self):
        self.grid = self.floor_obj.grid
    
    def draw_dungeon(self):
        for row in self.grid:
            for tile in row:
                try:
                    draw = self.tile_images[tile.terrain_type]
                    self.screen_rect.blit(draw, (tile.get_pos()[0] - self.x_offset, tile.get_pos()[1] - self.y_offset))
                except:
                    pass
    
    def order_dict_small_to_large(self, to_order_dict):
        keys_to_order = []
        for key in to_order_dict.keys():
            keys_to_order.append(key)
        for i in range(len(keys_to_order)):
            for j in range(len(keys_to_order) - 1):
                if to_order_dict[keys_to_order[j]] > to_order_dict[keys_to_order[j+1]]:
                    keys_to_order[j], keys_to_order[j+1] = keys_to_order[j+1], keys_to_order[j]
        return keys_to_order
    
    def draw_characters(self):
        ordered_entities = {}
        for entity in self.to_print:
            if entity.get_alive():
                ordered_entities[entity] = entity.get_y()
        ordered_entities = self.order_dict_small_to_large(ordered_entities)
        for entity in ordered_entities:
            entity_moving = entity.get_moving()
            if entity_moving:
                anim_to_get = "run_anim"
            else:
                anim_to_get = "idle_anim"
            entity.blit_sprite(self.screen_rect, anim_to_get, self.frame, self.x_offset, self.y_offset)
            