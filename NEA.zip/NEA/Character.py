import pygame
import random

class Character:
    def __init__(self, sprite_frames, bl_position, base_stats, tile_size):
        self.sprite_frames = sprite_frames
        
        self.stats = base_stats
        
        self.inventory = []
        
        self.equipped_item_index = None
        
        self.character_rect = self.sprite_frames["idle_anim"]["frames"][0].get_rect()
        self.character_rect.bottomleft = bl_position
        
        self.hit_box_rect = pygame.Rect((0, 0), (self.character_rect.width, self.character_rect.height//2))
        self.hit_box_rect.bottomleft = bl_position
        
        hit_box_center = self.hit_box_rect.center
        self.hit_box_rect.width -= 0.125*tile_size         #makes hitbox slimmer for easier access through 1x1 spaces
        self.hit_box_rect.center = hit_box_center
        
        self.facing_east = True
        self.moving = False
        self.alive = True
        self.ready_to_fight = True
        
        self.max_health = 100
        self.health = 80
        
    def set_equipped_index(self, index):
        if self.equipped_item_index is not None:
            self.inventory[self.equipped_item_index].set_equipped_status(False)
        self.equipped_item_index = index
        self.inventory[self.equipped_item_index].set_equipped_status(True)
        
    def set_item_index_equipped(self, index, status):
        self.inventory[index].set_equipped_status(status)
        
    def drop_item_index(self, index):
        if index == self.equipped_item_index:
            self.set_item_index_equipped(index, False)
            self.inventory.pop(index)
            self.set_item_index_equipped(0, True)
            self.equipped_item_index = 0
        elif index < self.equipped_item_index:
            self.equipped_item_index -= 1
            self.inventory.pop(index)
        else:
            self.inventory.pop(index)
        
    def get_item_at_index(self, index):
        return self.inventory[index]
        
    def get_equipped_index(self):
        return self.equipped_item_index
    
    def get_equipped_item(self):
        return self.inventory[self.equipped_item_index]
        
    def pick_up_item(self, item):
        self.inventory.append(item)
        
    def get_inventory(self):
        return self.inventory
        
    def set_ready_to_fight(self, value):
        self.ready_to_fight = value
        
    def get_ready_to_fight(self):
        return self.ready_to_fight
        
    def get_health(self):
        return self.health
    
    def get_max_health(self):
        return self.max_health
        
    def get_alive(self):
        return self.alive

    def is_in_range(self, entity, distance):
        bottom_left = self.get_bottom_left()
        entity_bottom_left = entity.get_bottom_left()
        if abs(entity_bottom_left[0] - bottom_left[0]) <= distance and abs(entity_bottom_left[1] - bottom_left[1]) <= distance:
            return True
        
    def set_alive_status(self, status):
        self.alive = status

    def check_collide(self, entity_rect):
        if self.hit_box_rect.colliderect(entity_rect):
            return True
        return False

    def get_y(self):
        return self.hit_box_rect.bottomleft[1]

    def get_moving(self):
        return self.moving

    def get_facing_east(self):
        return self.facing_east

    def get_hit_box_rect(self):
        return self.hit_box_rect
    
    def move_character_x(self, x):
        y = self.get_bottom_left()[1]
        self.move_character((x, y))
    
    def move_character_y(self, y):
        x = self.get_bottom_left()[0]
        self.move_character((x, y))    

    def update_facing_east(self, facing_east):
        self.facing_east = facing_east
        
    def update_moving(self, moving):
        self.moving = moving
    
    def blit_sprite(self, screen, anim_to_get, frame_to_get, x_offset = 0, y_offset = 0):
        if not self.ready_to_fight:
            anim_to_get = "idle_anim"
        screen.blit(self.get_frame(anim_to_get, frame_to_get), (self.get_top_left()[0] - x_offset, self.get_top_left()[1] - y_offset))
    
    def move_character(self, bl_position):
        self.character_rect.bottomleft = bl_position
        self.hit_box_rect.bottomleft = bl_position
        
    def get_top_left(self):
        return self.character_rect.topleft
    
    def get_bottom_left(self):
        return self.hit_box_rect.bottomleft    
    
    def get_static_frame(self, anim_to_get, frame_to_get):
        frames = self.sprite_frames[anim_to_get]["frames"]
        if frame_to_get >= len(frames):
            temp = frame_to_get
            frame_to_get -= (len(frames) - 1)
        frame = frames[frame_to_get]
        return frame    
    
    def get_frame(self, anim_to_get, frame_to_get):
        frame = self.sprite_frames[anim_to_get]["frames"][frame_to_get]
        frame = self.transform_frame(frame)
        return frame
    
    def transform_frame(self, frame):
        if not self.facing_east:
            frame = pygame.transform.flip(frame, True, False)
            frame.set_colorkey((0, 0, 0))
        return frame
    
    def get_rect(self):
        return self.hit_box_rect
    
class Player(Character):
    def __init__(self, sprite_frames, bl_position, base_stats, tile_size):
        Character.__init__(self, sprite_frames, bl_position, base_stats, tile_size)
        self.speed = 6

class Enemy(Character):
    def __init__(self, sprite_frames, bl_position, base_stats, tile_size):
        Character.__init__(self, sprite_frames, bl_position, base_stats, tile_size)
        self.pixels_per_iteration = random.randint(round(tile_size * 1/16), round(tile_size * 2/16))
        
    def move_to_pos(self, pos):
        x_total_move = pos[0] - self.character_rect.bottomleft[0]
        y_total_move = pos[1] - self.character_rect.bottomleft[1]
        self.moving = False                        
        if x_total_move > 0:
            x_direction = 1 #E
            self.facing_east = True
        elif x_total_move < 0:
            x_direction = -1 #W
            self.facing_east = False
        else:
            x_direction = 0
        if y_total_move < 0: #N
            y_direction = -1
        elif y_total_move > 0:
            y_direction = 1 #S
        else:
            y_direction = 0
        new_pos_x = (self.character_rect.bottomleft[0] + (self.pixels_per_iteration * x_direction))
        new_pos_y = (self.character_rect.bottomleft[1] + (self.pixels_per_iteration * y_direction))
        if self.pixels_per_iteration > abs(x_total_move):
            new_pos_x = (self.character_rect.bottomleft[0] + (x_total_move))
        if self.pixels_per_iteration > abs(y_total_move):
            new_pos_y = (self.character_rect.bottomleft[1] + (y_total_move))
        new_pos_rect_x = self.hit_box_rect.copy()
        new_pos_rect_y = self.hit_box_rect.copy()
        new_pos_rect_x.bottomleft = (new_pos_x, self.character_rect.bottomleft[1])
        new_pos_rect_y.bottomleft = (self.character_rect.bottomleft[0], new_pos_y)
        return new_pos_rect_x, new_pos_rect_y
        