import pygame
pygame.init()

SCREEN_WIDTH = 1080

SCREEN_HEIGHT = 700

screen = pygame.display
screen_rect = screen.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

temp = []

file1 = '/Fire'
file2 = '/Fireball'
#file1 = 
frames = []

count = 1
found_all = False
while not found_all:
    try:
        image = pygame.image.load('Combat_effect_images' + file1 + file2 + '/Frame ' + str(count) + '.png').convert_alpha()
        image = pygame.transform.scale(image, (500, 600))
        frames.append(image)
    except:
        found_all = True
    count += 1

frame = 0
new_frame = pygame.USEREVENT + 0
pygame.time.set_timer(new_frame, 105)
run = True
while run:
    screen_rect.fill((128, 128, 128))
    screen_rect.blit(frames[frame], (0, 0))
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        if event.type == new_frame:
            frame += 1
            if frame == len(frames):
                frame = 0    
    
    screen.update()