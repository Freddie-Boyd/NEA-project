from Dungeon import Dungeon

class Game:
    def __init__(self):
        self.dungeon = Dungeon()
        self.dungeon.start_loop()
        
g = Game()