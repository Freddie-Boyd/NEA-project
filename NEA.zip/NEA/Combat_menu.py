import pygame
from Button import Button

class Combat_menu:
    def __init__(self, main_surface, pos_of_surface, padding, modules, player): # modules["left"] = "Buttons" modules["right"] = "description"
        self.main_surface = main_surface
        self.pos_of_surface = pos_of_surface
        
        self.menu_surface_width = self.main_surface.get_width()
        self.menu_surface_height = self.main_surface.get_height()
        
        self.padding = padding
        self.padding_rects = 10
        
        self.modules = modules
        
        self.player = player
        
        self.selected_attack = None
        self.last_button = None
        
        self.reset_selected_index()
        
    def reset_selected_index(self):
        self.selected_item = self.player.get_character().get_equipped_index()
        
    def generate_menu(self, options = [], targets = []):
        self.options = options
        self.targets = targets
        self.menu_rects = {}
        rect_info = [{"name": "left", "colour": (52, 58, 64)}, {"name": "right", "colour": (52, 58, 64)}]
        count = 0
        for rect in rect_info:
            pos = [self.menu_surface_width//2*count + self.padding_rects, self.padding_rects]
            self.menu_rects[rect["name"]] = {"rect": pygame.Rect((pos), (self.menu_surface_width//2 - 2*self.padding_rects, self.menu_surface_height - 2*self.padding_rects)), "colour": rect["colour"]}
            count += 1
        self.buttons = []
        self.images = []
        self.inventory_items = []
        self.blank_inventory_items = []
        self.character_select_buttons = []
        for rect in rect_info:
            module = self.modules[rect["name"]]
            if module == "buttons":
                self.make_buttons_module(rect["name"])
            elif module == "inventory":
                self.make_inventory_module(rect["name"])
            elif module == "description":
                self.make_description_module(rect["name"])
            elif module == "inspect_item":
                self.make_inspect_module(rect["name"])
            elif module == "select_target":
                self.make_select_module(rect["name"])
    
    def make_select_module(self, side):
        width = round(self.menu_rects[side]["rect"].width/3 - self.padding)
        height = round(self.menu_rects[side]["rect"].height - self.padding)
        for i in range(len(self.targets)):
            image = self.targets[i].get_static_player_surface()
            x = self.menu_rects[side]["rect"].topleft[0] + width*i + self.padding*(i+0.5)
            y = self.menu_rects[side]["rect"].topleft[1] + self.padding*0.5
            b = Button(x, y, width, height, (73, 80, 87), (108, 117, 125), self.main_surface, str(i + 1))
            self.character_select_buttons.append({"button": b, "image": image, "index": i, "active": self.targets[i].get_character().get_alive()})
    
    def make_buttons_module(self, side):
        width = round(self.menu_rects[side]["rect"].width/len(self.options) - self.padding)
        height = round(self.menu_rects[side]["rect"].height/len(self.options[0]) - self.padding)
        for i in range(len(self.options)):
            for j in range(len(self.options[i])):
                x = self.menu_rects[side]["rect"].topleft[0] + width*i + self.padding*(i+0.5)
                y = self.menu_rects[side]["rect"].topleft[1] + height*j + self.padding*(j+0.5)
                b = Button(x, y, width, height, (73, 80, 87), (108, 117, 125), self.main_surface, self.options[i][j])
                self.buttons.append(b)
                
    def make_inventory_module(self, side):
        inv = self.player.get_character().get_inventory()
        width = round(self.menu_rects[side]["rect"].width/5 - self.padding)
        height = round(self.menu_rects[side]["rect"].height/2 - self.padding)
        count = 0
        for i in range(0, 2):
            for j in range(0, 5):
                x = self.menu_rects[side]["rect"].topleft[0] + width*j + self.padding*(j+0.5)
                y = self.menu_rects[side]["rect"].topleft[1] + height*i + self.padding*(i+0.5)
                if count < len(inv):
                    b = Button(x, y, width, height, (73, 80, 87), (108, 117, 125), self.main_surface, inv[count].get_name())                    
                    if count == self.selected_item:
                        b = Button(x, y, width, height, (52, 58, 64), (73, 80, 87), self.main_surface, inv[count].get_name())
                    image = inv[count].get_icon()
                    image = self.max_scale(width, height, image)
                    self.inventory_items.append({"button": b, "image": image, "index": count})
                else:
                    b = Button(x, y, width, height, (73, 80, 87), (108, 117, 125), self.main_surface, "")
                    self.blank_inventory_items.append({"button": b, "image": None, "index": count})
                count += 1
                
    def make_description_module(self, side): 
        self.menu_rects["description"] = {"rect": pygame.Rect((self.menu_rects[side]["rect"].topleft[0] + self.padding//2, self.menu_rects[side]["rect"].topleft[1] + self.padding//2), (self.menu_rects[side]["rect"].width - self.padding, self.menu_rects[side]["rect"].height - self.padding)), "colour": (128, 128, 128)}            
    
    def make_inspect_module(self, side):
        inv = self.player.get_character().get_inventory()
        
        width = round(self.menu_rects[side]["rect"].width/2 - self.padding)
        
        image_height = self.menu_rects[side]["rect"].height * (2/3) - self.padding
        button_height = self.menu_rects[side]["rect"].height * (1/3) - self.padding
        
        image_x = self.menu_rects[side]["rect"].topleft[0] + self.padding*0.5
        image_y = self.menu_rects[side]["rect"].topleft[1] + self.padding*0.5
        
        back_button_x = self.menu_rects[side]["rect"].topleft[0] + self.padding*0.5
        back_button_y = image_y + image_height + self.padding
        
        back_button = Button(back_button_x, back_button_y, width, button_height, (73, 80, 87), (108, 117, 125), self.main_surface, "Back")
        image_button = Button(image_x, image_y, width, image_height, (73, 80, 87), (108, 117, 125), self.main_surface, "Image")        
        
        actions = inv[self.selected_item].get_actions()
        
        button_height = min(round(self.menu_rects[side]["rect"].height/2 - self.padding), round(self.menu_rects[side]["rect"].height/len(actions) - self.padding))
        button_x = self.menu_rects[side]["rect"].topleft[0] + width + 1.5*self.padding
        
        count = 0
        for action in actions:
            if not (len(inv) <= 1 and action == "Discard"):
                button_y = self.menu_rects[side]["rect"].topleft[1] + (count + 0.5)*self.padding + count*button_height
                b = Button(button_x, button_y, width, button_height, (73, 80, 87), (108, 117, 125), self.main_surface, action)                
                if action == "Equipped":
                    b = Button(button_x, button_y, width, button_height, (62, 68, 74), (73, 80, 87), self.main_surface, action)     
                self.buttons.append(b)
                count += 1
                

        image = inv[self.selected_item].get_icon()
        image = self.max_scale(width, image_height, image)
        
        self.buttons.append(back_button)
        self.images.append({"image": image, "button": image_button})
            
    def max_scale(self, width, height, image):
        y_mod = (height - 10)/image.get_height()
        x_mod = (width - 10)/image.get_width()
        used_mod = min(y_mod, x_mod)
        image = pygame.transform.scale(image, (round(image.get_width()*used_mod), round(image.get_height()*used_mod)))
        return image
    
    def get_selected_index(self):
        return self.selected_item

    def set_selected_index(self, new_index):
        self.selected_item = new_index
    
    def get_button_pressed(self):
        for button in self.buttons:
            if button.is_button_pressed(self.pos_of_surface):
                if self.last_button is not None:
                    self.last_button.set_colour((73, 80, 87), (108, 117, 125))
                self.last_button = button
                return button.get_option()
        
        for character_select_button in self.character_select_buttons:
            if character_select_button["button"].is_button_pressed(self.pos_of_surface) and character_select_button["active"]:
                return character_select_button["button"].get_option()

    def set_selected_attack(self, option):
        self.selected_attack = option
        
    def get_item_pressed(self):
        last_item = self.selected_item
        for item in self.inventory_items:
            if item["button"].is_button_pressed(self.pos_of_surface):
                self.selected_item = item["index"]
        return last_item, self.selected_item
    
    def get_selected_attack(self):
        return self.selected_attack
    
    def draw(self):
        for rect in self.menu_rects:
            pygame.draw.rect(self.main_surface, self.menu_rects[rect]["colour"], self.menu_rects[rect]["rect"])
            
        for button in self.buttons:
            if button.get_option() == self.selected_attack:
                button.set_colour((52, 58, 64), (73, 80, 87))
            else:
                button.set_colour((73, 80, 87), (108, 117, 125))
            button.draw()
            
        for image_info in self.images:
            image_info["button"].draw(with_text = False)
            pos = image_info["button"].get_center()
            pos[0] -= image_info["image"].get_width()//2
            pos[1] -= image_info["image"].get_height()//2            
            self.main_surface.blit(image_info["image"], pos)

        for character_select_button in self.character_select_buttons:
            character_select_button["button"].draw(with_text = False)
            pos = character_select_button["button"].get_center()
            pos[0] -= character_select_button["image"].get_width()//2
            pos[1] -= character_select_button["image"].get_height()//2
            self.main_surface.blit(character_select_button["image"], pos)

        for item in self.inventory_items:
            pos = item["button"].get_center()
            pos[0] -= item["image"].get_width()//2
            pos[1] -= item["image"].get_height()//2
            item["button"].draw(0, False)
            self.main_surface.blit(item["image"], pos)
            
        for item in self.blank_inventory_items:
            item["button"].draw(0, False)
