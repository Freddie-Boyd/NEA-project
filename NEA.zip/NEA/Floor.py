import pygame
import random
import math
from Room import Room
from Corridor import Corridor
from Spritesheet import Spritesheet
from Room_terrain_tile import Room_terrain_tile

pygame.init()

class Floor_generator:
    def __init__(self, WIDTH, HEIGHT, tile_size, floor, wall):        
        self.tile_size = tile_size
        
        self.start_location = None

        self.floor = floor
        self.wall2 = wall     
        
        self.num_of_rooms = random.randint(7, 13)
        self.grid_width = 60
        self.grid_height = 60
        
        self.grid = self.gen_grid()
        self.room_data = self.gen_rooms()
        self.order_rooms()
        self.gen_corridor()
        self.make_walls()
        self.remove_inner_walls()
        
    def gen_grid(self):
        grid = []
        self.floor_tiles = []
        for i in range(0, self.grid_height):
            row = []
            for j in range(0, self.grid_width):
                row.append(None)#Room_terrain_tile("wall_2", (j * self.tile_size, i * self.tile_size), False, self.wall2))
            grid.append(row)
        return grid
        
    def get_start_location(self):
        return self.start_location
        
    def gen_rooms(self):
        room_data = []
        size_min = 6
        size_max = 13
        for i in range(self.num_of_rooms):
            dimensions = (random.randint(size_min, size_max), random.randint(size_min, size_max))
            
            tl_position = [random.randint(2, self.grid_width - (dimensions[0] + 2)), random.randint(2, self.grid_height - (dimensions[1] + 2))]
            
            room = Room(i, dimensions, tl_position)
            
            self.grid_add_room(room)

            room_data.append(room)
        return room_data
    
    def grid_add_room(self, room):
        for i in range(room.dimensions[1]):
            for j in range(room.dimensions[0]):
                grid_y = room.tl_position[1] + i
                grid_x = room.tl_position[0] + j             
                self.grid[grid_y][grid_x] = Room_terrain_tile("floor_1", True, self.floor,  (grid_y, grid_x), self.tile_size)
                self.floor_tiles.append(self.grid[grid_y][grid_x])
                
    def gen_corridor(self):
        for i in range(self.num_of_rooms - 1):
            current_room_center = self.room_data[i].get_center()
            next_room_center = self.room_data[i + 1].get_center()
            y_size = next_room_center[1] - current_room_center[1]
            if y_size >= 0:
                top_left = (current_room_center[0], next_room_center[1])
            else:
                top_left = (current_room_center[0], current_room_center[1])
            self.create_corridor_on_grid(top_left, abs(y_size), "y")
            
            x_size = next_room_center[0] - current_room_center[0]
            if x_size >= 0:
                top_left = (current_room_center[0], next_room_center[1])
            else:
                top_left = (next_room_center[0], next_room_center[1])
            self.create_corridor_on_grid(top_left, abs(x_size), "x")
            
    def create_corridor_on_grid(self, top_left, size, x_or_y):
        x_move, y_move = 0, 0
        for i in range(size + 1):
            if x_or_y == "x":
                x_move = i
            else:
                y_move = i
            y_pos = top_left[1] - y_move
            x_pos = top_left[0] + x_move
            self.grid[y_pos][x_pos] = Room_terrain_tile("floor_1", True, self.floor,  (y_pos, x_pos), self.tile_size)            
            self.floor_tiles.append(self.grid[y_pos][x_pos])
        
    def order_rooms(self):
        ordered_rooms = [self.room_data[0]]
        for n in range(1, len(self.room_data)):
            pos = ordered_rooms[-1].get_center()
            ordered_rooms.append(self.find_next_room(ordered_rooms, pos))
        self.room_data = ordered_rooms

    #def find_next_room(self, ordered_rooms, pos):
        #size = 0
        #while True:
            #size += 1
            #if size > len(self.grid[0]):
                #print("error", ordered_rooms, size)
                #return
            #for i in range(-size, size + 1):
                #for j in range(-size, size + 1):
                    #for room in self.room_data:
                        #if room.is_pos_in((pos[0] + j, pos[1] + i)) and not room in ordered_rooms:
                            #print(room, ordered_rooms)
                            #return room
                            
    def find_next_room(self, ordered_rooms, pos):
        centers = {}
        for room in self.room_data:
            if not room in ordered_rooms:
                centers[room] = math.sqrt((room.get_center()[0] - pos[0])**2 + (room.get_center()[1] - pos[1])**2)
                return self.order_dict_small_to_large(centers)[0]
                    
    def order_dict_small_to_large(self, to_order_dict):
        keys_to_order = []
        for key in to_order_dict.keys():
            keys_to_order.append(key)
        for i in range(len(keys_to_order)):
            for j in range(len(keys_to_order) - 1):
                if to_order_dict[keys_to_order[j]] > to_order_dict[keys_to_order[j+1]]:
                    keys_to_order[j], keys_to_order[j+1] = keys_to_order[j+1], keys_to_order[j]
        return keys_to_order
    
    def make_walls(self):
        self.walls = []
        for tile in self.floor_tiles:
            pos = tile.get_grid_pos()
            if self.start_location is None:
                print(pos)
                self.start_location = pos
            for row in range(-1, 2):
                for column in range(-1, 2):
                    y_pos = pos[0] + row
                    x_pos = pos[1] + column
                    if self.grid[y_pos][x_pos] == None:
                        wall = Room_terrain_tile("wall_2", False, self.wall2, (y_pos, x_pos), self.tile_size)
                        self.walls.append(wall)
                        self.grid[y_pos][x_pos] = wall
                        
    def remove_inner_walls(self):
        for wall in self.walls:
            found = False
            pos = wall.get_grid_pos()
            for row in range(-1, 2):
                for column in range(-1, 2):
                    y_pos = pos[0] + row
                    x_pos = pos[1] + column
                    if self.grid[y_pos][x_pos] == None:
                        found = True
            if not found:
                #return
                self.grid[pos[0]][pos[1]] = Room_terrain_tile("floor_1", True, self.floor, pos, self.tile_size)            
                self.floor_tiles.append(self.grid[pos[0]][pos[1]])