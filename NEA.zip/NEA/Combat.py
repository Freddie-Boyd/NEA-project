import pygame
import random
import os
import sys
from Combat_menu import Combat_menu

pygame.init()

clock = pygame.time.Clock()

BACKGROUND_IMAGE_DIRECTORY = "Backgrounds\Combat_backgrounds"
BACKGROUND_FRAMES = 8

FPS = 30

IMAGE_SCALE = 3
SCALE = 1.2

PLAYER_POSITION_X_MOD = 7
PLAYER_POSITION_Y_MOD = 1.15

ENEMY_POSITION_X_MOD = 3
ENEMY_POSITION_Y_MOD = 1.25

BONUS_COMBAT_HEIGHT = 30

PERCENT_OPTION = 3.5

NORMAL_TILE_SIZE = 32

class Combat:
    def __init__(self, player, enemies, screen, tile_size):
        combatant_scale = IMAGE_SCALE/(tile_size/NORMAL_TILE_SIZE)
        self.player = Combatant(player, combatant_scale)
        
        self.screen_rect = screen
        self.screen_width = self.screen_rect.get_rect().width
        self.screen_height = self.screen_rect.get_rect().height        
        
        self.enemies = []
        for enemy in enemies:
            self.enemies.append(Combatant(enemy, combatant_scale))
            
        self.attack_frames_to_blit = []
            
        self.load_rects()
        self.load_background()
        self.format_main_menu()
            
    def load_rects(self):
        self.menu_surface_width = self.screen_width
        self.menu_surface_height = round(self.screen_height/PERCENT_OPTION)
        self.menu_surface = pygame.Surface((self.menu_surface_width, self.menu_surface_height)).convert_alpha()
        self.menu_surface_position = (0, self.screen_height - self.menu_surface_height)
        
        self.combat_surface_width = self.screen_width
        self.combat_surface_height = self.screen_height - self.menu_surface_height      
        self.combat_surface = pygame.Surface((self.combat_surface_width, self.combat_surface_height)).convert_alpha()
        self.combat_surface_position = (0, 0)
    
    def load_background(self):
        self.background_frames = []
        for filename in os.listdir(BACKGROUND_IMAGE_DIRECTORY):
            if filename.endswith(".png"):
                background_image = pygame.image.load(os.path.join(BACKGROUND_IMAGE_DIRECTORY, filename)).convert_alpha()
                background_image = pygame.transform.scale(background_image, (self.combat_surface_width, self.combat_surface_height))
                self.background_frames.append(background_image)
            else:
                continue        
    
    def start_combat(self):
        self.new_frame = pygame.USEREVENT + 2
        self.button_cooldown = pygame.USEREVENT + 3
        self.new_attack_frame = pygame.USEREVENT + 4
        self.check_buttons = True
        pygame.time.set_timer(self.new_frame, 190)
        pygame.time.set_timer(self.new_attack_frame, 80)
        self.background_frame = 0
        self.frame = 0
        self.frame_move = 1
        run = True
        self.continue_combat = True
        while run and self.continue_combat:
            
            self.blit_background()
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                    run = False
                if event.type == self.new_attack_frame:
                    if self.attack_frames_to_blit != []:
                        self.attack_frames_to_blit.pop(0)                    
                if event.type == self.new_frame:
                    self.frame += 1
                    if self.frame == 4:
                        self.frame = 0                    
                    self.background_frame += self.frame_move
                    if self.background_frame == len(self.background_frames)-1:
                        self.frame_move = -1
                    elif self.background_frame == 0:
                        self.frame_move = 1
                if event.type == self.button_cooldown:
                    self.check_buttons = True
                    pygame.time.set_timer(self.button_cooldown, 0)
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_i:
                        self.continue_combat = False
                        

            self.draw_characters()
            
            self.screen_rect.blit(self.update_fps(), (10, 0))
            
            self.blit_surfaces()
            
            if self.check_buttons:
                self.check_menu_buttons()
            
            if self.attack_frames_to_blit != []:
                pos = [0, 0]
                frame = self.attack_frames_to_blit[0][0]
                enemy_index = self.attack_frames_to_blit[0][1]
                pos[0], pos[1] = self.enemies[enemy_index].get_image_bottom_left()[0] - frame.get_width()//2, self.enemies[enemy_index].get_image_bottom_left()[1] - frame.get_height()
                self.screen_rect.blit(self.attack_frames_to_blit[0][0], pos)
            
            clock.tick(FPS)
            
            self.check_continue_combat()
            
            pygame.display.update()
            
    def check_continue_combat(self):
        if not self.player.get_character().get_alive():
            self.continue_combat = False
            return
        dead_count = 0
        for enemy in self.enemies:
            if enemy.get_character_alive():
                return
            else:
                dead_count += 1
        if dead_count == len(self.enemies):
            self.continue_combat = False
            
    def check_menu_buttons(self):
        pressed_button = self.menus[self.active_menu].get_button_pressed()
        last_item, item_pressed = self.menus[self.active_menu].get_item_pressed()
        if last_item != item_pressed:
            self.inventory_menu.generate_menu()
            self.draw_active_menu()
        if pressed_button is None:
            return
        elif pressed_button == "Fight":
            self.last_active_menu, self.active_menu = self.active_menu, "fight"
            
        elif pressed_button == "Inventory":
            self.last_active_menu, self.active_menu = self.active_menu, "inventory"  
            
        elif pressed_button == "Back":
            self.last_active_menu, self.active_menu = self.active_menu, self.last_active_menu
            
        elif pressed_button == "Run":
            for enemy in self.enemies:
                enemy.character.set_ready_to_fight(False)
            self.continue_combat = False
            
        elif pressed_button == "Equip":         
            self.player.get_character().set_equipped_index(item_pressed)
            self.menus[self.active_menu].reset_selected_index()
            self.inventory_menu.generate_menu()
            self.update_fight_menu()
            
        elif pressed_button == "Discard":
            self.player.get_character().drop_item_index(item_pressed)
            self.menus[self.active_menu].reset_selected_index()
            self.inventory_menu.generate_menu()
            self.update_fight_menu()
            
        elif pressed_button in ["1", "2", "3"]:
            for attack in self.player.get_character().get_equipped_item().get_all_attacks():          
                attack_name = self.menus[self.active_menu].get_selected_attack()
                if attack_name == attack["name"]:
                    enemy_index = int(pressed_button) - 1
                    self.handle_attacks(attack, enemy_index)
                    self.menus[self.active_menu].set_selected_attack(None)
                    self.update_fight_menu()
        else:
            for attack in self.player.get_character().get_equipped_item().get_all_attacks():
                attack_name = attack["name"]
                if pressed_button == attack_name:
                    self.menus[self.active_menu].set_selected_attack(attack_name)
        self.draw_active_menu()
        self.check_buttons = False
        pygame.time.set_timer(self.button_cooldown, 300)
        
    def update_fight_menu(self):
        count = 0
        fight_menu_button_names = [[], []]
        for attacks in self.player.get_character().get_equipped_item().get_all_attacks():
            attack_name = attacks["name"]
            fight_menu_button_names[count].append(attack_name)
            if count == 0:
                count = 1
            else:
                count = 0
        fight_menu_button_names[0].append("Back")
        
        self.fight_menu.generate_menu(fight_menu_button_names, self.enemies)
        self.menus["fight"] = self.fight_menu
        
    def handle_attacks(self, attack, enemy_index):
        print("handling attack", attack)
        enemy = self.enemies[enemy_index].get_character()
        for frame in attack["frames"]:
            frame = pygame.transform.scale(frame, (frame.get_width()*2, frame.get_height()*2))
            self.attack_frames_to_blit.append([frame, enemy_index])
        enemy.health -= attack["damage"]
        if enemy.health <= 0:
            self.enemies[enemy_index].set_should_print(False)
            self.enemies[enemy_index].get_character().set_alive_status(False)
        
    def format_main_menu(self):
        #modules will be [buttons, description, inventory, item_info, select_target]
        main_menu_button_names = [["Fight", "Run"], ["Inventory"]]
        main_menu_modules = {"left": "buttons", "right": "description"}
        self.main_menu = Combat_menu(self.menu_surface, self.menu_surface_position, 10, main_menu_modules, self.player)
        self.main_menu.generate_menu(main_menu_button_names)
        
        
        fight_menu_modules = {"left": "buttons", "right": "select_target"}
        self.fight_menu = Combat_menu(self.menu_surface, self.menu_surface_position, 10, fight_menu_modules, self.player)
        count = 0
        fight_menu_button_names = [[], []]
        for attacks in self.player.get_character().get_equipped_item().get_all_attacks():
            attack_name = attacks["name"]
            fight_menu_button_names[count].append(attack_name)
            if count == 0:
                count = 1
            else:
                count = 0
        fight_menu_button_names[0].append("Back")
        self.fight_menu.generate_menu(fight_menu_button_names, self.enemies)
        
        
        inventory_menu_modules = {"left": "inspect_item", "right": "inventory"}
        self.inventory_menu = Combat_menu(self.menu_surface, self.menu_surface_position, 10, inventory_menu_modules, self.player)
        self.inventory_menu.generate_menu()
        
        self.menus = {"main": self.main_menu, "fight": self.fight_menu, "inventory": self.inventory_menu}
        
        self.last_active_menu = None
        self.active_menu = "main"
        self.draw_active_menu()
            
    def blit_surfaces(self):
        self.screen_rect.blit(self.combat_surface, self.combat_surface_position)
        self.screen_rect.blit(self.menu_surface, self.menu_surface_position)
            
    def draw_active_menu(self):
        self.menu_surface.fill((33, 37, 41))
        self.menus[self.active_menu].draw()
            
    def update_fps(self):
        font = pygame.font.SysFont("Arial", 18)
        fps = str(int(clock.get_fps()))
        fps_text = font.render(fps, 1, pygame.Color("coral"))
        return fps_text
            
    def blit_background(self):
        self.combat_surface.blit(self.background_frames[self.background_frame], (0, 0))
    
    def draw_characters(self):
        self.x_pos_player = self.combat_surface_width/PLAYER_POSITION_X_MOD
        self.y_pos_player = self.combat_surface_height/PLAYER_POSITION_Y_MOD        
        self.player.draw_combatant(self.frame, (self.x_pos_player, self.y_pos_player), self.combat_surface, False)
        self.x_pos_enemy = self.combat_surface_width//ENEMY_POSITION_X_MOD
        self.y_pos_enemy = self.y_pos_player - 40
        x_spare_length = (self.combat_surface_width - self.x_pos_enemy)
        for enemy in self.enemies:
            x_spare_length -= enemy.get_surface_width()
        x_padding = x_spare_length//len(self.enemies)
        for enemy in self.enemies:
            enemy.draw_combatant(self.frame, (self.x_pos_enemy, self.y_pos_enemy), self.combat_surface, True)
            self.x_pos_enemy += enemy.get_surface_width() + x_padding

        
class Combatant:
    def __init__(self, character, image_scale):
        self.image_scale = image_scale
        self.character = character
        self.anim_to_get = "idle_anim"
        self.player_surface = pygame.Surface((0, 0)).convert_alpha()
        self.update_surface(0, False)
        self.static_player_surface = self.make_static_player_surface(0, True)
        self.should_print = True
        
    def set_should_print(self, status):
        self.should_print = status
        
    def make_static_player_surface(self, frame, flip):
        player_surface = pygame.Surface((0, 0)).convert_alpha()
        player_image = self.character.get_static_frame(self.anim_to_get, frame)
        player_image = pygame.transform.scale(player_image, (round(player_image.get_width()), round(player_image.get_height())))
        player_surface = pygame.transform.scale(player_surface, (round(player_image.get_width()), round(player_image.get_height())))
        
        image_x_pos = player_surface.get_width() - player_image.get_width()
        image_y_pos = player_surface.get_height() - player_image.get_height() - BONUS_COMBAT_HEIGHT
        
        player_surface.fill((0, 0, 0))
        player_surface.blit(player_image, (0, 0))
        player_surface.set_colorkey((0, 0, 0))
        player_surface = pygame.transform.flip(player_surface, flip, False).convert_alpha()
        return player_surface
        
    def draw_health(self, x_pos, max_width):
        max_height = 20
        padding1 = 10
        padding2 = 4
        
        max_health = self.character.get_max_health()
        health = self.character.get_health()
        
        self.info_bar_surface = pygame.Surface((max_width, max_height)).convert_alpha()
        surface_center = (self.info_bar_surface.get_width()//2, self.info_bar_surface.get_height()//2)
        self.info_bar_surface.fill((34, 34, 59))
        
        max_health_width = self.info_bar_surface.get_width() - padding1
        max_health_height = self.info_bar_surface.get_height() - padding1
        max_health_rect = pygame.Rect((0, 0), (max_health_width, max_health_height))
        max_health_rect.center = surface_center
        pygame.draw.rect(self.info_bar_surface, (108, 117, 125), max_health_rect)
        
        health_width = max_health_width/max_health * health
        health_rect1 = pygame.Rect((0, 0), (health_width, max_health_height))
        health_rect1.topleft = max_health_rect.topleft
        pygame.draw.rect(self.info_bar_surface, (116, 2, 5), health_rect1)
        
        health_rect2 = pygame.Rect((0, 0), (health_width - padding2, max_health_height - padding2))
        health_rect2.center = health_rect1.center
        pygame.draw.rect(self.info_bar_surface, (170, 0, 13), health_rect2)
        
        y_pos = self.get_surface_height() - self.info_bar_surface.get_height()
        self.player_surface.blit(self.info_bar_surface, (x_pos, y_pos))
        
    def draw_combatant(self, frame, position, screen, flip):
        if not self.should_print:
            return
        
        self.update_surface(frame, flip)
        
        self.surface_x_pos = position[0]
        self.surface_y_pos = position[1] - self.get_surface_height()

        screen.blit(self.player_surface, (self.surface_x_pos, self.surface_y_pos))
        
    def update_surface(self, frame, flip):
        player_image = self.character.get_static_frame(self.anim_to_get, frame)
        player_image = pygame.transform.scale(player_image, (round(player_image.get_width()*self.image_scale), round(player_image.get_height()*self.image_scale)))
        self.player_surface = pygame.transform.scale(self.player_surface, (round(player_image.get_width()*SCALE), round(player_image.get_height()*SCALE) + BONUS_COMBAT_HEIGHT))
        
        self.image_x_pos = self.player_surface.get_width() - player_image.get_width()
        self.image_y_pos = self.player_surface.get_height() - player_image.get_height() - BONUS_COMBAT_HEIGHT
        
        self.player_surface.fill((0, 0, 0))
        #self.player_surface.fill((128, 128, 128))
        self.player_surface.blit(player_image, (self.image_x_pos, self.image_y_pos))
        self.player_surface.set_colorkey((0, 0, 0))
        if not flip:
            self.draw_health(self.image_x_pos, player_image.get_width())
        else:
            self.image_x_pos = 0
            self.player_surface = pygame.transform.flip(self.player_surface, True, False).convert_alpha()
            self.draw_health(self.image_x_pos, player_image.get_width())
        
    def get_static_player_surface(self):
        return self.static_player_surface
        
    def get_character(self):
        return self.character
    
    def get_character_alive(self):
        return self.character.get_health()
    
    def get_surface_width(self):
        return self.player_surface.get_width()
    
    def get_surface_height(self):
        return self.player_surface.get_height()
    
    def get_image_bottom_left(self):
        return (self.surface_x_pos ,self.surface_y_pos + self.get_surface_height())
    
    def get_image_top_left(self):
        return (self.surface_x_pos + self.image_x_pos, self.surface_y_pos + self.image_y_pos)