import pygame

class Corridor:
    def __init__(self, corridor_num, dimensions, top_left):
        self.dimensions = dimensions
        self.corridor_num = corridor_num
        self.top_left

