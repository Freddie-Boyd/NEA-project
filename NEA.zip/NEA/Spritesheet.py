import pygame

class Spritesheet:
    def __init__(self, sprite_sheet_image, tile_size, text_filename):
        self.sprite_sheet_image = pygame.image.load(sprite_sheet_image).convert_alpha()
        self.sprites = {}
        
        self.tile_size = tile_size
        
        self.scale = tile_size//16
        
        self.floor = pygame.Surface(((16), 16)).convert_alpha()
        self.floor.blit(self.sprite_sheet_image, (0, 0), (16, 64, 16, 16))
        self.floor = pygame.transform.scale(self.floor, (tile_size, tile_size))
        self.floor.set_colorkey((0, 0, 0))
         
        self.wall2 = pygame.Surface((16, 16)).convert_alpha()
        self.wall2.blit(self.sprite_sheet_image, (0, 0), (32, 16, 16, 16))
        self.wall2 = pygame.transform.scale(self.wall2, (tile_size, tile_size))
        self.wall2.set_colorkey((0, 0, 0))             
        
        self.load_sprites(text_filename)
        
    def get_sprite(self, sprite_type, sprite_name):
        sprite = self.sprites[sprite_type][sprite_name]
        return sprite

    def get_sprite_frames(self, x, y, width, height, num_of_frames):
        frames = []
        x, y = int(x), int(y)
        width, height = int(width), int(height)
        
        num_of_frames = int(num_of_frames)
        for i in range(num_of_frames):
            image = pygame.Surface((width, height)).convert_alpha()
            image.blit(self.sprite_sheet_image, (0, 0), ((x + (width * i)) , y, width, height))
            image = pygame.transform.scale(image, (width * self.scale, height * self.scale))
            image.set_colorkey((0, 0, 0))
            frames.append(image)
        return frames

    def load_sprites(self, text_filename):
        data = {}
        f = open(text_filename + ".txt","r")
        lines = f.readlines()
        char_data = {}
        last_line_char = None
        for line in lines:
            line = (line.strip()).split()
            if not line == []:
                line_description = line[0].split("_")
                
                line_char_sections = line_description[:-2]
                line_char = line_char_sections[0]
                for i in range(1, len(line_char_sections)):
                    line_char += "_" + line_char_sections[i]
                line_type = line_description[-2] +  "_" + line_description[-1]
                char_data[line_type] = {"frames":self.get_sprite_frames(line[1], line[2], line[3], line[4], line[5])}
            else:
                data[line_char] = char_data
                char_data = {}
                last_line_char = line_char
        data[line_char] = char_data
                
                
        self.sprites[text_filename] = data
        f.close()