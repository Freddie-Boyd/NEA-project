import pygame
import random
import math

WEAPONS = {
    "Shortsword": {"Basic_attack": {"damage": 10, "cost": 10}, "Flurry": {"damage": 10, "cost": 10}, "Assassinate": {"damage": 10, "cost": 10}},
    "Sword": {"Basic_attack": {"damage": 10, "cost": 10}, "Spin_to_win": {"damage": 10, "cost": 10}, "Decisive_blow": {"damage": 10, "cost": 10}},
    "Hammer": {"Basic_attack": {"damage": 10, "cost": 10}, "Large_swing": {"damage": 10, "cost": 10}, "Ground_slam": {"damage": 10, "cost": 10}},
    "Dagger": {"Basic_attack": {"damage": 10, "cost": 10}},
    "Axe": {"Basic_attack": {"damage": 10, "cost": 10}, "Cleave": {"damage": 10, "cost": 10}, "Beheading": {"damage": 10, "cost": 10}},
    "Bat": {"Basic_attack": {"damage": 10, "cost": 10}, "Beat_to_a_pulp": {"damage": 10, "cost": 10}, "The_tenderiser": {"damage": 10, "cost": 10}}
}

ELEMENTAL_ATTACKS = {
    "Fire": {"Fireball": {"damage": 10, "cost": 10}, "Explosion": {"damage": 10, "cost": 10}, "Death_beam": {"damage": 10, "cost": 10}},
    "Lightning": {"Zap": {"damage": 10, "cost": 10}, "Overcharge": {"damage": 10, "cost": 10}, "Lightning_strike": {"damage": 10, "cost": 10}},
    "Rock": {"Rock_smash": {"damage": 10, "cost": 10}, "Rock_hammer": {"damage": 10, "cost": 10}, "Rock_spike": {"damage": 10, "cost": 10}}, 
    "Water": {"Water_ball": {"damage": 10, "cost": 10}, "Water_portal": {"damage": 10, "cost": 10}, "Waterspout": {"damage": 10, "cost": 10}}, 
    "Wind": {"First_strike": {"damage": 10, "cost": 10}, "Whirlewind": {"damage": 10, "cost": 10}, "Large_flurry": {"damage": 10, "cost": 10}}
}

WEAPON_ICONS = {
    "Shortsword": {"S": "weapon_golden_sword", "A": "weapon_golden_sword", "B": "weapon_saw_sword", "C": "weapon_red_gem_sword", "D": "weapon_regular_sword"}, 
    "Sword": {"S": "weapon_lavish_sword", "A": "weapon_anime_sword", "B": "weapon_knight_sword", "C": "weapon_katana", "D": "weapon_duel_sword"},
    "Hammer": {"S": "weapon_big_hammer", "A": "weapon_big_hammer", "B": "weapon_hammer", "C": "weapon_hammer", "D": "weapon_hammer"},
    "Dagger": {"S": "weapon_knife", "A": "weapon_knife", "B": "weapon_knife", "C": "weapon_knife", "D": "weapon_knife"}, 
    "Bat": {"S": "weapon_mace", "A": "weapon_mace", "B": "weapon_baton_with_spikes", "C": "weapon_baton_with_spikes", "D": "weapon_baton_with_spikes"}, 
    "Axe": {"S": "weapon_machete", "A": "weapon_machete", "B": "weapon_cleaver", "C": "weapon_axe", "D": "weapon_axe"}
}

class Weapon_generator:
    def __init__(self):
        self.weapons = {}
        self.elements = {}
        self.weapon_icons = {}
        
        self.load_weapons()
        self.load_elemental_attacks()
        self.load_icons()
        
    def load_weapons(self):
        for name in WEAPONS.keys():
            attacks = []
            for attack in WEAPONS[name].keys():
                frames = []
                file_name = "/" + name + "/" + attack
                count = 1
                found_all = False
                while not found_all:
                    try:
                        image = pygame.image.load("Combat_effect_images/Basic/Basic_attacks" + file_name + "/Frame "  + str(count) + ".png").convert_alpha()
                        frames.append(image)
                    except:
                        found_all = True
                    count += 1
                    
                attacks.append({"name": attack, "damage": WEAPONS[name][attack]["damage"], "cost": WEAPONS[name][attack]["cost"], "frames": frames})
                    
            self.weapons[name] = attacks
    
    def load_icons(self):
        for name in WEAPON_ICONS.keys():
            weap_icons = {}
            for tier in WEAPON_ICONS[name].keys():
                file_name = "/" + name + "/" + WEAPON_ICONS[name][tier]
                image = pygame.image.load("Weapons" + file_name + ".png").convert_alpha()
                weap_icons[tier] = image
            self.weapon_icons[name] = weap_icons
    
    def load_elemental_attacks(self):
        for name in ELEMENTAL_ATTACKS.keys():
            attacks = []
            for attack in ELEMENTAL_ATTACKS[name].keys():
                frames = []
                file_name = "/" + name + "/" + attack
                count = 1
                found_all = False
                while not found_all:
                    try:
                        image = pygame.image.load("Combat_effect_images" + file_name + "/Frame "  + str(count) + ".png").convert_alpha()
                        frames.append(image)
                    except:
                        found_all = True
                    count += 1
                    
                attacks.append({"name": attack, "damage": ELEMENTAL_ATTACKS[name][attack]["damage"], "cost": ELEMENTAL_ATTACKS[name][attack]["cost"], "frames": frames})
                    
            self.elements[name] = attacks
            
    def generate_random_weapons(self, amount, floor):
        tier = self.generate_tier(floor)
        weapon_type = self.generate_weapon_type()
        element = self.generate_element(floor)
        weapon_info = {
            "weapon_type": weapon_type,
            "element": element,
            "tier": tier
                }
        weapon = self.generate_specific_weapon(weapon_info)
        return weapon
        
        
    def generate_element(self, floor): #make it so this is scaling with floor level
        element_types = self.elements.keys()
        a = []
        for element_type in element_types:
            a.append(element_type)        
        a.append(None)
        index = random.randint(0, len(a) - 1)
        return a[index]
        
    def generate_weapon_type(self):
        weapon_types = self.weapons.keys()
        a = []
        for weapon_type in weapon_types:
            a.append(weapon_type)        
        index = random.randint(0, len(a) - 1)
        return a[index]
        
    def generate_tier(self, floor):
        p = 0.15 + (0.5 * floor)
        n = 10
        
        teirs = ["D", "D", "C", "C", "B", "B", "A", "A", "S", "S"]
        
        sucesses = 0
        for i in range(n + 1):
            num = random.randint(0, 100)
            if num >= p*100:
                sucesses += 1
                
        return teirs[sucesses]
    
    def generate_specific_weapon(self, weapon_info):
        w_attacks = self.weapons[weapon_info["weapon_type"]].copy()
        print(w_attacks)
        if weapon_info["element"] is not None:
            w_attacks.append(self.elements[weapon_info["element"]][(self.tier_to_rank(weapon_info["tier"]) - 1)])
        icon = self.weapon_icons[weapon_info["weapon_type"]][weapon_info["tier"]]
        w = Weapon(weapon_info["weapon_type"], weapon_info["element"], weapon_info["tier"], w_attacks, icon)
        return w
        
    def tier_to_rank(self, tier):
        if tier == "S":
            rank = 3
            return rank
        elif tier == "A" or tier == "B":
            rank = 2
            return rank
        else:
            rank = 1
            return rank

    
class Weapon:
    def __init__(self, weapon_type, element, tier, attacks, icon):
        self.weapon_type = weapon_type
        self.element = element
        self.tier = tier
        self.attacks = attacks
        self.icon = icon
        
        self.actions = ["Equip", "Discard"]
        
        self.equipped = False
        
    def get_actions(self):
        return self.actions
    
    def change_actions(self, index, new_action):
        self.actions[index] = new_action
        
    def set_equipped_status(self, status):
        self.equipped = status
        if status:
            self.change_actions(0, "Equipped")
        else:
            self.change_actions(0, "Equip")        
        
    def get_name(self):
        return self.weapon_type
    
    def get_icon(self):
        return self.icon
    
    def get_element (self):
        return self.element
    
    def get_tier(self):
        return self.tier
    
    def get_all_attacks(self):
        return self.attacks