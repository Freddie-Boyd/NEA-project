from Button import Button
import pygame

class Menu:
    def __init__(self, padding_between_options, bg_image, main_colour, sec_colour, menu_title, menu_options, SCREEN_WIDTH, SCREEN_HEIGHT):
        self.bg_image = bg_image
        self.main_colour = pygame.Color(main_colour)
        self.sec_colour = pygame.Color(sec_colour)
        self.padding_between_options = padding_between_options
        
        self.avalible_screen_width = SCREEN_WIDTH
        self.avalible_screen_height = SCREEN_HEIGHT - self.padding_between_options
        
        self.menu_title = menu_title
        self.screen = pygame.display
        self.screen_rect = self.screen.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption(menu_title)
        self.menu_options = menu_options
        
    def menu_loop(self):
        
        self.make_menu()
        
        run = True
        button_pressed = None
        while run and button_pressed is None:
            self.draw_menu()
            
            button_pressed = self.check_button_pressed()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    run = False
            
            self.screen.update()
            
        self.screen.quit()
        return button_pressed
            
    def check_button_pressed(self):
        for button in self.menu_buttons:
            if button.is_button_pressed():
                return button.get_option()
        return None
            
    def make_menu(self):
        
        self.menu_buttons = []
        self.number_of_options = len(self.menu_options) + 1
        
        segment = self.avalible_screen_height//self.number_of_options
        
        button_width = self.avalible_screen_width/2
        button_height = segment - self.padding_between_options        
        
        count = 0
        for option in self.menu_options:
            count += 1
            start_x = self.avalible_screen_width//4
            start_y = ((self.avalible_screen_height//self.number_of_options) * (count)) + self.padding_between_options
            menu_button = Button(start_x, start_y, button_width, button_height, self.main_colour, self.sec_colour, self.screen_rect, option)
            self.menu_buttons.append(menu_button)
            
    def draw_title(self):
        font = pygame.font.SysFont('Arial', 50)
        
        title_text = font.render(self.menu_title, True, self.sec_colour)
        
        title_rect = title_text.get_rect(center = (self.avalible_screen_width//2, (self.avalible_screen_height//self.number_of_options)//2))
        
        self.screen_rect.blit(title_text, title_rect)        
            
    def draw_menu(self):
        self.draw_background()
        self.draw_title()
        for button in self.menu_buttons:
            button.draw()
            
            
    def draw_background(self):
        background_image = pygame.image.load(self.bg_image).convert_alpha()
        background_image = pygame.transform.scale(background_image, (self.screen_rect.get_rect().width, self.screen_rect.get_rect().height))
        self.screen_rect.blit(background_image, (0, 0))        
    
def main():
    pass
    
if __name__ == "__main__":
    main()