from Menu import Menu
from Game import Game

import pygame

MAIN_MENU_OPTIONS = ["New Game", "Load Game", "Quit"]

MAIN_MENU_HEIGHT = 700

MAIN_MENU_WIDTH = 700

MAIN_MENU_MAIN_COLOUR = "#F7DC6F"

MAIN_MENU_SEC_COLOUR = "#FFC300"

MAIN_MENU_BG_IMAGE = "Backgrounds\Menu_background.png"

MAIN_MENU_TITLE = "Main Menu"

PADDING_BETWEEN_OPTIONS = 50

pygame.mouse.set_cursor(pygame.cursors.Cursor(*pygame.cursors.tri_left))

class Main:
    def __init__(self):
        self.run_menu()
                
    def run_menu(self):
        self.menu = Menu(PADDING_BETWEEN_OPTIONS, MAIN_MENU_BG_IMAGE, MAIN_MENU_MAIN_COLOUR, MAIN_MENU_SEC_COLOUR,
                         MAIN_MENU_TITLE, MAIN_MENU_OPTIONS, MAIN_MENU_WIDTH, MAIN_MENU_HEIGHT)
        function_to_run = self.menu.menu_loop()
        if function_to_run == "New Game":
            self.new_game()
        elif function_to_run == "Load Game":
            self.load_game()
        elif function_to_run == "Quit":
            self.quit()
                
    def quit(self):
        quit()
        
    def load_game(self):
        print("Load game")
        
    def new_game(self):
        self.new_game = Game()
                    
if __name__ == "__main__":
    Dungeon_Game = Main()