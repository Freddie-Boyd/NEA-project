import pygame

class Room_terrain_tile:
    def __init__(self, terrain_type, is_walkable, tile_image, grid_pos, tile_size):
        self.terrain_type = terrain_type
        
        self.grid_pos = grid_pos

        self.is_walkable = is_walkable

        self.rect = pygame.Rect((0, 0), (tile_size, tile_size))
        self.rect.topleft = (self.grid_pos[0]*tile_size, self.grid_pos[1]*tile_size)

    def is_colliding(self, rect_to_check):
        if self.rect.colliderect(rect_to_check):
            return True
    
    def get_grid_pos(self):
        return self.grid_pos
    
    def get_pos(self):
        return self.rect.topleft

        