import pygame

class Room:
    def __init__(self, room_num, dimensions, tl_position):
        self.tl_position = tl_position
        self.dimensions = dimensions
        self.room_num = room_num
    
    def get_top_left(self):
        return self.tl_position
    
    def is_pos_in(self, pos):
        if pos[0] > self.tl_position[0] and pos[0] < (self.tl_position[0] + self.dimensions[0]):
            if pos[1] > self.tl_position[1] and pos[1] < (self.tl_position[1] + self.dimensions[1]):
                return True

    
    def get_dimensions(self):
        return self.dimensions    
    
    def get_center(self):
        center = (self.tl_position[0] + self.dimensions[0]//2, self.tl_position[1] + self.dimensions[1]//2)
        return center